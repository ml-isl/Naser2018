module.exports = function (site) {

  site.get({
    name: '/x-js',
    path: __dirname + '/site_files/js'
  })

  site.get({
    name: '/x-css',
    path: __dirname + '/site_files/css'
  })
  site.get({
    name: '/x-semantic-themes',
    path: __dirname + '/site_files/semantic-themes'
  })
  
  site.get({
    name: '/x-fonts',
    path: __dirname + '/site_files/fonts'
  })


  site.get({
    name: "/x-css/site.css",
    parser: "css2",
    compress: true,
    path: [
      __dirname + "/site_files/css/theme.css",
      __dirname + "/site_files/css/layout.css",
      __dirname + "/site_files/css/print.css",
      __dirname + "/site_files/css/images.css",
      __dirname + "/site_files/css/navbar.css",
      __dirname + "/site_files/css/form.css",
      __dirname + "/site_files/css/modal.css",
      __dirname + "/site_files/css/fixed_menu.css",
      __dirname + "/site_files/css/color.css",
      __dirname + "/site_files/css/effect.css",
      __dirname + "/site_files/css/table.css",
      __dirname + "/site_files/css/tableExport.css"
    ]
  })

}